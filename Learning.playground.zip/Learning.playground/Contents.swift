//: Playground - noun: a place where people can play

//import UIKit

// w3 Resource Basic Exercises

/*

func Sum_Three(val1: Int, val2: Int) -> Int {
    var result: Int
    if (val1 == val2)
    {
        result = 3 * (val1 + val2)
    }
    else
    {
        result = val1 + val2
    }
    return result
}

func Abs51(n: Int) -> Int {
    var result: Int
    if (n > 51)
    {
        result = 2 * abs(51 - n)
    }
    else
    {
        result = abs(51 - n)
    }
    return result
}

func Is20(val1: Int, val2: Int) -> Bool{
    if (val1 == 20 || val2 == 20 || (val1 + val2) == 20)
    {
        return true
    }
    else
    {
        return false
    }
}

func NOR(val1: Int, val2: Int) -> Bool {
    if ((val1 > 0 && val2 < 0) || (val1 < 0 && val2 > 0) || (val1 < 0 && val2 < 0))
    {
        return true
    }
    else
    {
        return false
    }
}

func Is_String(str: String) -> String {
    let start = str.startIndex
    let end = str.index(str.startIndex, offsetBy: 2)
    let range = start..<end
    var result: String = str
    
    if (str[range] != "Is" )
    {
        result = "Is " + str
    }
    return result
}

func Rmv_char(str: String, num: Int) -> String {
    var result: String
    
    if ((num > 0) && (num < str.count - 1))
    {
        let index_bef = str.index(str.startIndex, offsetBy: num - 1)
        let index_aft = str.index(str.startIndex, offsetBy: num)
        
        let beg_str = str.prefix(upTo: index_bef)
        let end_str = str.suffix(from: index_aft)
        result = String(beg_str) + String(end_str)
    }
    else
    {
        print("Entered number exceeds index range: String unchanged")
        result = str
    }
    return result
}

func Swap(str: String) -> String {
    var result: String
    
    if (str.count > 0)
    {
        let first_char = str[str.startIndex]
        let last = str.index(before: str.endIndex)
        let last_char = str[last]
        
        let start = str.index(str.startIndex, offsetBy: 1)
        let end = str.index(str.endIndex, offsetBy: -1)
        let range = start..<end
        let middle = str[range]
        
        result = String(last_char) + String(middle) + String(first_char)
    }
    else{
        print("String length not long enough")
        result = str
    }
    return result
}
func Add_last(str: String) -> String {
    var result: String
    if (str.count > 0)
    {
        let last_char = str[str.index(before: str.endIndex)]
        result = String(last_char) + str + String(last_char)
    }
    else
    {
        print("String length not long enough")
        result = str
    }
    return result
}

func Mult3_5(num: Int) -> Bool {
    if ((num % 3 == 0) || (num % 5 == 0))
    {
        return true
    }
    else
    {
        return false
    }
}

func add2(str: String) -> String {
    let result :String
    
    let end = str.index(str.startIndex, offsetBy: 2)
    let chars = str.prefix(upTo: end)
    
    result = String(chars) + str + String(chars)
    return result
}

func Is(str: String) -> Bool {
    
    let start = str.index(str.startIndex, offsetBy: 0)
    let end = str.index(str.startIndex, offsetBy: 2)
    let range = start..<end
    
    let check = String(str[range])
    
    if (check == "Is")
    {
        return true
    }
    else
    {
        return false
    }
}

func Btwn10_30(num1: Int, num2: Int) -> Bool {
    if ((num1 > 10 && num1 < 30) || (num2 > 10 && num2 < 30))
    {
        return true
    }
    else
    {
        return false
    }
}

func _ix(str: String) -> Bool {
    let start = str.index(str.startIndex, offsetBy: 1)
    let end = str.index(str.startIndex, offsetBy: 3)
    let range = start..<end
    let check = str[range]
    
    if (check == "ix")
    {
        return true
    }
    else
    {
        return false
    }
}

func Largest(num1: Int, num2: Int, num3: Int) -> Int {
    if (num1 > num2 && num1 > num3)
    {
        return num1
    }
    else if (num2 > num3)
    {
        return num2
    }
    else
    {
        return num3
    }
}

func Close_10(num1: Int, num2: Int) -> Int {
    if (abs(10 - num1) > abs(10 - num2))
    {
        return num2
    }
    else if (abs(10 - num1) < abs(10 - num2))
    {
        return num1
    }
    else
    {
        return 0
    }
}

func Btwn_20_30_40(num1: Int, num2: Int) -> Bool {
    if (((num1 > 20 && num1 < 30) && (num2 > 20 && num2 < 30)) || ((num1 > 30 && num1 < 40) && (num2 > 30 && num2 < 40)))
    {
        return true
    }
    else
    {
        return false
    }
}

func Btwn_20_30(num1: Int, num2: Int) -> Int {
    var lrg: Int
    var sml: Int
    if (num1 > num2)
    {
        lrg = num1
        sml = num2
    }
    else
    {
        lrg = num2
        sml = num1
    }
    if (lrg >= 20 && lrg <= 30)
    {
        return lrg
    }
    else if (sml >= 20 && sml <= 30)
    {
        return sml
    }
    else
    {
        return 0
    }
}

func last_dig(num1: Int, num2: Int) -> Bool{
    if (num1 % 10 == num2 % 10)
    {
        return true
    }
    else
    {
        return false
    }
}

*/

func Upper_Last_3(str: String) -> String {
    if (str.count <= 3)
    {
        return str.uppercased()
    }
    else
    {
        var result = str
        let last_3 = str.suffix(3)
        result.removeLast(3)
        result.append(String(last_3.uppercased()))
        return result
    }
}

func a_a(str:String) -> Bool {
    var index = 0
    for char in str
    {
        if (char == "a")
        {
            if (str[str.index(str.startIndex, offsetBy: index + 1)] == "a")
            {
                return true
            }
            else
            {
                return false
            }
        }
        index += 1
    }
    print("No 'a' character detected")
    return false
}

func other_char(str: String) -> String {
    var index = 0
    var result = ""
    for char in str
    {
        if ((index % 2) == 0)
        {
            result.append(char)
        }
        index += 1
    }
    return result
}

func num_7(nums: [Int]) -> Int {
    var count = 0
    for num in nums
    {
        if (num == 7)
        {
            count += 1
        }
    }
    return count
}

func is_7(nums: [Int]) -> Bool {
    var max = 4
    if (nums.count < 4)
    {
        max = nums.count
    }
    if (nums.prefix(max).contains(7))
    {
        return true
    }
    else
    {
        return false
    }
}

func find0_1_2(nums: [Int]) -> Bool{
    for(index, number) in nums.enumerated()
    {
        let index_2 = index + 1
        let index_3 = index + 2
        if (index_3 < nums.endIndex && number == 0 && nums[index_2] == 1 && nums[index_3] == 2)
        {
            return true
        }
    }
    return false
}

func rmv_a(str: String) -> String{
    
    var result: String
    let start = str.index(str.startIndex, offsetBy: 1)
    let end = str.index(str.endIndex, offsetBy: -1)
    let range = start..<end
    
    var middle = str[range]
    while (middle.contains("a"))
    {
        middle.remove(at: middle.index(of: "a")!)
    }
    result = String(str.prefix(1)) + String(middle) + String(str.suffix(1))
    return result
}

func every_other(str: String) -> String {
    var index = 0
    var result = ""
    for char in str
    {
        if (index % 2 == 0)
        {
            result.append(char)
        }
        index += 1
    }
    return result
}

func next_7s(nums: [Int]) -> Int {
    var result = 0
    var next_index: Int
    for (index, num) in nums.enumerated()
    {
        next_index = index + 1
        if (next_index < nums.endIndex && num == 7 && nums[next_index] == 7)
        {
            result += 1
        }
    }
    return result
}

func triples(nums: [Int]) -> Bool {
    var index_2: Int
    var index_3: Int
    for (index, num) in nums.enumerated()
    {
        index_2 = index + 1
        index_3 = index + 2
        if (index_3 < nums.endIndex && nums[index_2] == num && nums[index_3] == num)
        {
            return true
        }
    }
    return false
}

//print(triples(nums: [1,1,2,2,2,3,4]))
//print(next_7s(nums: [7,1,2,7]))
//print(every_other(str: "wasdwasd"))
//print(rmv_a(str: "aaaaalol"))
//print(find0_1_2(nums: [0,1,2]))
//print(is_7(nums: [1,2,7]))
//print(num_7(nums: [7,7,8,7]))
//print(other_char(str: "Xcode"))
//print(a_a(str: "waasd"))
//print(Upper_Last_3(str: "xcode"))
//print(last_dig(num1: 11, num2: 201))
//print(Btwn_20_30(num1: 20, num2: 21))
//print(Btwn_20_30_40(num1: 21, num2: 31))
//print(Close_10(num1: 15, num2: 11))
//print(Largest(num1: 5, num2: 4, num3: 3))
//print(_ix(str: "fix"))
//print(Btwn10_30(num1: 10, num2: 31))
//print(Is(str: "aIs"))
//print(add2(str: "Wasd"))
//print(Mult3_5(num: 0))
//print(Add_last(str: "Wasd"))
//print(Abs51( n: 55))
//print(Sum_Three(val1: 3, val2: 3))
//print(Is20( val1: 1, val2: 2))
//print(NOR(val1: -1, val2: 2))
//print(Is_String(str: "Is a"))
//print(Rmv_char(str: "String", num: 0))
//print(Swap(str: "Macbook"))
