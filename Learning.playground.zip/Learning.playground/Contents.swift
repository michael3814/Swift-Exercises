//: Playground - noun: a place where people can play

//import UIKit

// w3 Resource Basic Exercises

func Sum_Three(val1: Int, val2: Int) -> Int {
    var result: Int
    if (val1 == val2)
    {
        result = 3 * (val1 + val2)
    }
    else
    {
        result = val1 + val2
    }
    return result
}

func Abs51(n: Int) -> Int {
    var result: Int
    if (n > 51)
    {
        result = 2 * abs(51 - n)
    }
    else
    {
        result = abs(51 - n)
    }
    return result
}

func Is20(val1: Int, val2: Int) -> Bool{
    if (val1 == 20 || val2 == 20 || (val1 + val2) == 20)
    {
        return true
    }
    else
    {
        return false
    }
}

func NOR(val1: Int, val2: Int) -> Bool {
    if ((val1 > 0 && val2 < 0) || (val1 < 0 && val2 > 0) || (val1 < 0 && val2 < 0))
    {
        return true
    }
    else
    {
        return false
    }
}

func Is_String(str: String) -> String {
    let start = str.startIndex
    let end = str.index(str.startIndex, offsetBy: 2)
    let range = start..<end
    var result: String = str
    
    if (str[range] != "Is" )
    {
        result = "Is " + str
    }
    return result
}



//print(Abs51( n: 55))
//print(Sum_Three(val1: 3, val2: 3))
//print(Is20( val1: 1, val2: 2))
//print(NOR(val1: -1, val2: 2))
//print(Is_String(str: "Is a"))
